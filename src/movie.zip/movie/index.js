import RouterApp from './route/index';
const AppMovie =()=>{
    return(
        <RouterApp/>
    )
}
export default AppMovie;