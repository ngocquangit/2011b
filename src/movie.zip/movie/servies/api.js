import jwt from 'jsonwebtoken';
const keyToken = 'RJ2011B';
const checkUserLogin = (user,pass) => {
    let token=null;
    if(user==='a' && pass==='1')
    {
        token = jwt.sign({
            id:1,
            username:user,
            email:'admin@gmail.com',
            phone:'0123456789',
            address:'Ha Noi'
         }, keyToken)
    }
    return token;
}

export const api ={
    checkUserLogin
}