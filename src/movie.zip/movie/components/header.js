import React from 'react';
import { Layout, Menu } from 'antd';
import styled from 'styled-components';
import {Link,useLocation} from 'react-router-dom';
const DivLogo = styled.div`
            float: left;
            width: 120px;
            height: 31px;
            margin: 16px 24px 16px 0;
            background: rgba(255, 255, 255, 0.3);`;
const { Header } = Layout;
const HeaderComponent = () =>{
    const {pathname} =useLocation();
    return(
        <Header>
      <DivLogo className="logo" />
      <Menu theme="dark" mode="horizontal" defaultSelectedKeys={pathname}>
        <Menu.Item key="/search">
            <Link to="/search"> Tìm kiếm</Link></Menu.Item>
        <Menu.Item key="/popular">
            <Link to="/popular">Phim nổi bật</Link></Menu.Item>
        <Menu.Item key="/upcoming">
            <Link to="/">Sắp chiếu</Link></Menu.Item>
        <Menu.Item key="/login">
            <Link to="/login">Đăng nhập</Link></Menu.Item>
      </Menu>
    </Header>
    )
}
export default React.memo(HeaderComponent);