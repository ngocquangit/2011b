import React,{lazy,Suspense} from "react";
import {Skeleton} from "antd";
import {
    BrowserRouter as Router,
    Switch,
    Route
  } from "react-router-dom";
// import SearchPages from "../pages/search/index";
// import PopularPages from "../pages/popular/index";
// import LoginPages from "../pages/login/index";
const SearchPages = lazy(()=> import('../pages/search/index'));
const PopularPages = lazy(()=> import('../pages/popular/index'));
const LoginPages = lazy(()=> import('../pages/login/index'));

const RouteMovie = () =>{
    return(
        <Router>
            <Suspense fallback={<Skeleton active/>}>
                <Switch>
                    <Route path="/" exact> 
                    <SearchPages/>
                    </Route>
                    <Route path="/search"> 
                    <SearchPages/>
                    </Route>
                    <Route path="/popular"> 
                    <PopularPages/>
                    </Route>
                    <Route path="/login"> 
                    <LoginPages/>
                    </Route>
                </Switch>
            </Suspense>
        </Router>
    )
}
export default React.memo(RouteMovie);