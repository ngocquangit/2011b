import React from 'react';
import MasterLayout from '../../components/masterLayout';
 const SearchMoviePage = ()=>{
     return(
         <MasterLayout>
             <h1>ahihi</h1>
         </MasterLayout>
     )
 }
 export default SearchMoviePage;