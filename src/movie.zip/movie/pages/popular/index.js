import React from 'react';
import MasterLayout from '../../components/masterLayout';
 const PopularMoviePage = ()=>{
     return(
         <MasterLayout>
             <h1>Xem nhiều</h1>
         </MasterLayout>
     )
 }
 export default PopularMoviePage;