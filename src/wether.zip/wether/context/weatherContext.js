import React from 'react'

const WeatherContext = React.createContext();
export default WeatherContext;